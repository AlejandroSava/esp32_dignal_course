#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

/* These must come from kyber/ref via -I... */
//#include "api.h"          /* <-- defines CRYPTO_*BYTES */
#include "kem.h"          /* <-- crypto_kem_* prototypes */
#include "randombytes.h"



void print_hex(const char *label, const uint8_t *buf, size_t len)
{
    printf("%s (%zu bytes):\n", label, len);
    for (size_t i = 0; i < len; i++) {
        printf("0x%02X", buf[i]);
        if ((i + 1) % 16 == 0)
            printf("\n");
        else
            printf(" ");
    }
    if (len % 16 != 0)
        printf("\n");
}

void clear_parameters(const char *label, uint8_t *buf, size_t len){
    printf("Cleaning the next parameter %s\n", label);
    memset(buf, 0, len);
}



int write_bin(const char *filename, const uint8_t *buf, size_t len)
{
    FILE *f = fopen(filename, "wb");
    if (!f) return -1;

    if (fwrite(buf, 1, len, f) != len) {
        fclose(f);
        return -1;
    }

    fclose(f);
    return 0;
}

int read_bin(const char *filename, uint8_t *buf, size_t len)
{
    FILE *f = fopen(filename, "rb");
    if (!f) return -1;

    if (fread(buf, 1, len, f) != len) {
        fclose(f);
        return -1;
    }

    fclose(f);
    return 0;
}



int main(void)
{
  uint8_t pk[CRYPTO_PUBLICKEYBYTES];
  uint8_t sk[CRYPTO_SECRETKEYBYTES];
  uint8_t ct[CRYPTO_CIPHERTEXTBYTES];
  uint8_t key_a[CRYPTO_BYTES];
  uint8_t key_b[CRYPTO_BYTES];
  // start the initialization cleaning all the parameters
  // CLEAR THE PARAMETERS  
  clear_parameters("Public Key (pk)", pk, CRYPTO_PUBLICKEYBYTES);
  clear_parameters("Secret Key (sk)", sk, CRYPTO_SECRETKEYBYTES);
  clear_parameters("Ciphertext (ct)", ct, CRYPTO_CIPHERTEXTBYTES);
  clear_parameters("Shared Key A", key_a, CRYPTO_BYTES);
  clear_parameters("Shared Key B", key_b, CRYPTO_BYTES);
  
   // PRINT CURRENT STATUS
  print_hex("Public Key (pk)", pk, CRYPTO_PUBLICKEYBYTES);
  print_hex("Secret Key (sk)", sk, CRYPTO_SECRETKEYBYTES);
  print_hex("Ciphertext (ct)", ct, CRYPTO_CIPHERTEXTBYTES);
  print_hex("Shared Key A", key_a, CRYPTO_BYTES);
  print_hex("Shared Key B", key_b, CRYPTO_BYTES);
  
  
  printf("------ READING THE FILES --------\n");
  read_bin("/home/alejandro/my_kyber_example/sk.bin", sk, CRYPTO_SECRETKEYBYTES);
  read_bin("/home/alejandro/my_kyber_example/ct.bin", ct, CRYPTO_CIPHERTEXTBYTES);

  
  // PRINT CURRENT STATUS
  print_hex("Public Key (pk)", pk, CRYPTO_PUBLICKEYBYTES);
  print_hex("Secret Key (sk)", sk, CRYPTO_SECRETKEYBYTES);
  print_hex("Ciphertext (ct)", ct, CRYPTO_CIPHERTEXTBYTES);
  print_hex("Shared Key A", key_a, CRYPTO_BYTES);
  print_hex("Shared Key B", key_b, CRYPTO_BYTES);
  
  printf("3 -------- CRYPTO_KEM_DEC DECRYPTION ----------- \n");
  crypto_kem_dec(key_a, ct, sk); // ALICE: Third step, get its own 
  
  // PRINT CURRENT STATUS
  print_hex("Public Key (pk)", pk, CRYPTO_PUBLICKEYBYTES);
  print_hex("Secret Key (sk)", sk, CRYPTO_SECRETKEYBYTES);
  print_hex("Ciphertext (ct)", ct, CRYPTO_CIPHERTEXTBYTES);
  print_hex("Shared Key A", key_a, CRYPTO_BYTES);
  print_hex("Shared Key B", key_b, CRYPTO_BYTES);
  
  printf("------ WRITING THE FILES --------\n");
  write_bin("/home/alejandro/my_kyber_example/key_a.bin", key_a, CRYPTO_BYTES);
  

  return 0;
}

