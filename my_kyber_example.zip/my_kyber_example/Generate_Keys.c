#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

/* These must come from kyber/ref via -I... */
//#include "api.h"          /* <-- defines CRYPTO_*BYTES */
#include "kem.h"          /* <-- crypto_kem_* prototypes */
#include "randombytes.h"



void print_hex(const char *label, const uint8_t *buf, size_t len)
{
    printf("%s (%zu bytes):\n", label, len);
    for (size_t i = 0; i < len; i++) {
        printf("%02X", buf[i]);
        if ((i + 1) % 16 == 0)
            printf("\n");
        else
            printf(" ");
    }
    if (len % 16 != 0)
        printf("\n");
}

void clear_parameters(const char *label, uint8_t *buf, size_t len){
    printf("Cleaning the next parameter %s\n", label);
    memset(buf, 0, len);
}



int write_bin(const char *filename, const uint8_t *buf, size_t len)
{
    FILE *f = fopen(filename, "wb");
    if (!f) return -1;

    if (fwrite(buf, 1, len, f) != len) {
        fclose(f);
        return -1;
    }

    fclose(f);
    return 0;
}

int read_bin(const char *filename, uint8_t *buf, size_t len)
{
    FILE *f = fopen(filename, "rb");
    if (!f) return -1;

    if (fread(buf, 1, len, f) != len) {
        fclose(f);
        return -1;
    }

    fclose(f);
    return 0;
}



int main(void)
{
  uint8_t pk[CRYPTO_PUBLICKEYBYTES];
  uint8_t sk[CRYPTO_SECRETKEYBYTES];
  uint8_t ct[CRYPTO_CIPHERTEXTBYTES];
  uint8_t key_a[CRYPTO_BYTES];
  uint8_t key_b[CRYPTO_BYTES];
  // start the initialization cleaning all the parameters
  // CLEAR THE PARAMETERS  
  clear_parameters("Public Key (pk)", pk, CRYPTO_PUBLICKEYBYTES);
  clear_parameters("Secret Key (sk)", sk, CRYPTO_SECRETKEYBYTES);
  clear_parameters("Ciphertext (ct)", ct, CRYPTO_CIPHERTEXTBYTES);
  clear_parameters("Shared Key A", key_a, CRYPTO_BYTES);
  clear_parameters("Shared Key B", key_b, CRYPTO_BYTES);
  
   // PRINT CURRENT STATUS
  print_hex("Public Key (pk)", pk, CRYPTO_PUBLICKEYBYTES);
  print_hex("Secret Key (sk)", sk, CRYPTO_SECRETKEYBYTES);
  print_hex("Ciphertext (ct)", ct, CRYPTO_CIPHERTEXTBYTES);
  print_hex("Shared Key A", key_a, CRYPTO_BYTES);
  print_hex("Shared Key B", key_b, CRYPTO_BYTES);
  
  
  printf("1 -------- CRYPTO_KEM_KEYPAIR GENERATION ----------- \n");
  crypto_kem_keypair(pk, sk); // ALICE: first step, generate the keys pk and sk, 
  
  // PRINT CURRENT STATUS
  print_hex("Public Key (pk)", pk, CRYPTO_PUBLICKEYBYTES);
  print_hex("Secret Key (sk)", sk, CRYPTO_SECRETKEYBYTES);
  print_hex("Ciphertext (ct)", ct, CRYPTO_CIPHERTEXTBYTES);
  print_hex("Shared Key A", key_a, CRYPTO_BYTES);
  print_hex("Shared Key B", key_b, CRYPTO_BYTES);
  
  printf("2 -------- CRYPTO_KEM_ENC ENCRYPTION ----------- \n");
  crypto_kem_enc(ct, key_b, pk); // BOB: second step, create the ct and key_b according to previous information
  
  
  // PRINT CURRENT STATUS
  print_hex("Public Key (pk)", pk, CRYPTO_PUBLICKEYBYTES);
  print_hex("Secret Key (sk)", sk, CRYPTO_SECRETKEYBYTES);
  print_hex("Ciphertext (ct)", ct, CRYPTO_CIPHERTEXTBYTES);
  print_hex("Shared Key A", key_a, CRYPTO_BYTES);
  print_hex("Shared Key B", key_b, CRYPTO_BYTES);
  
  printf("3 -------- CRYPTO_KEM_DEC DECRYPTION ----------- \n");
  crypto_kem_dec(key_a, ct, sk); // ALICE: Third step, get its own 
  
  // PRINT CURRENT STATUS
  print_hex("Public Key (pk)", pk, CRYPTO_PUBLICKEYBYTES);
  print_hex("Secret Key (sk)", sk, CRYPTO_SECRETKEYBYTES);
  print_hex("Ciphertext (ct)", ct, CRYPTO_CIPHERTEXTBYTES);
  print_hex("Shared Key A", key_a, CRYPTO_BYTES);
  print_hex("Shared Key B", key_b, CRYPTO_BYTES);

  printf("CRYPTO_SECRETKEYBYTES:  %d\n", CRYPTO_SECRETKEYBYTES);
  printf("CRYPTO_PUBLICKEYBYTES:  %d\n", CRYPTO_PUBLICKEYBYTES);
  printf("CRYPTO_CIPHERTEXTBYTES: %d\n", CRYPTO_CIPHERTEXTBYTES);
  

  
  clear_parameters("Shared Key B", key_b, CRYPTO_BYTES);
  print_hex("Shared Key B", key_b, CRYPTO_BYTES);

  
  if (memcmp(key_a, key_b, CRYPTO_BYTES)) {
    printf("ERROR keys\n");
    return 1;
  }
  printf("The test was sucess\n");
  
  return 0;
}

